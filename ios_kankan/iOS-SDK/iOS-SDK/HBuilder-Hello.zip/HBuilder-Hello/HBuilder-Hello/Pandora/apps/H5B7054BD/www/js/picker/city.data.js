var cityData = [{
		"value": 1,
		"text": "北海道"
	},
	{
		"value": 8011,
		"text": "青森県"
	},
	{
		"value": 10043,
		"text": "岩手県"
	},
	{
		"value": 11954,
		"text": "宮城県"
	},
	{
		"value": 14749,
		"text": "秋田県"
	},
	{
		"value": 16900,
		"text": "山形県"
	},
	{
		"value": 18840,
		"text": "福島県"
	},
	{
		"value": 22437,
		"text": "茨城県"
	},
	{
		"value": 25284,
		"text": "栃木県"
	},
	{
		"value": 27114,
		"text": "群馬県"
	},
	{
		"value": 28611,
		"text": "埼玉県"
	},
	{
		"value": 31540,
		"text": "千葉県"
	},
	{
		"value": 35122,
		"text": "東京都"
	},
	{
		"value": 38853,
		"text": "神奈川県"
	},
	{
		"value": 41134,
		"text": "新潟県"
	},
	{
		"value": 46471,
		"text": "富山県"
	},
	{
		"value": 49442,
		"text": "石川県"
	},
	{
		"value": 51892,
		"text": "福井県"
	},
	{
		"value": 54020,
		"text": "山梨県"
	},
	{
		"value": 54960,
		"text": "長野県"
	},
	{
		"value": 56625,
		"text": "岐阜県"
	},
	{
		"value": 59955,
		"text": "静岡県"
	},
	{
		"value": 62826,
		"text": "愛知県"
	},
	{
		"value": 69857,
		"text": "三重県"
	},
	{
		"value": 72305,
		"text": "滋賀県"
	},
	{
		"value": 74139,
		"text": "京都府"
	},
	{
		"value": 80555,
		"text": "大阪府"
	},
	{
		"value": 84317,
		"text": "兵庫県"
	},
	{
		"value": 89486,
		"text": "奈良県"
	},
	{
		"value": 91389,
		"text": "和歌山県"
	},
	{
		"value": 92984,
		"text": "鳥取県"
	},
	{
		"value": 94374,
		"text": "島根県"
	},
	{
		"value": 95550,
		"text": "岡山県"
	},
	{
		"value": 97728,
		"text": "広島県"
	},
	{
		"value": 99845,
		"text": "山口県"
	},
	{
		"value": 101486,
		"text": "徳島県"
	},
	{
		"value": 102447,
		"text": "香川県"
	},
	{
		"value": 103156,
		"text": "愛媛県"
	},
	{
		"value": 104887,
		"text": "高知県"
	},
	{
		"value": 106576,
		"text": "福岡県"
	},
	{
		"value": 109856,
		"text": "佐賀県"
	},
	{
		"value": 110726,
		"text": "長崎県"
	},
	{
		"value": 112617,
		"text": "熊本県"
	},
	{
		"value": 114477,
		"text": "大分県"
	},
	{
		"value": 116304,
		"text": "宮崎県"
	},
	{
		"value": 117179,
		"text": "鹿児島県"
	},
	{
		"value": 118629,
		"text": "沖縄県"
	}
]